const Login = () => {
  return (
    <div>
      <h2>Login page</h2>
    </div>
  );
};

export default Login;

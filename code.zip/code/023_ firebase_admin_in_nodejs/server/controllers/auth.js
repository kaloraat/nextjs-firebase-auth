export const currentUser = (req, res) => {
  console.log("REQ HEADERS TOKEN", req.headers.token);
};

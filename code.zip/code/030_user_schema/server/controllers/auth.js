import admin from "../firebase";

export const currentUser = async (req, res) => {
  // console.log("REQ HEADERS TOKEN", req.headers.token);
  try {
    const firebaseUser = await admin.auth().verifyIdToken(req.headers.token);
    console.log("FIREBASE USER IN CURRENT USER MIDDLEWARE", firebaseUser);
    // save the user to db or send user response if it is already saved
    res.json(firebaseUser);
  } catch (err) {
    console.log(err);
    res.status(401).json({
      err: "Invalid or expired token",
    });
  }
};

export const privateRoute = async (req, res) => {
  console.log("REQ HEADERS TOKEN IN PRIVATE ROUTE", req.headers.token);
  res.json({
    ok: true,
  });
};

module.exports = {
  env: {
    api: "http://localhost:8000/api",
  },
};

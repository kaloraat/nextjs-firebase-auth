module.exports = {
  env: {
    api: "http://localhost:8000/api",
    passwordResetRedirect: "http://localhost:3000/login",
  },
};
